package servlet.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.CallableStatement;
import com.mysql.jdbc.Connection;

public class JDBC extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public JDBC() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		
		response.setContentType("text/html;charset=UTF-8");
		String driverName="com.mysql.jdbc.Driver"; 
		//数据库信息
		java.sql.Connection Conn = null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String user = "root";
			String psw = "lyh2o16";
			String url = "jdbc:mysql://123.206.82.143/library-manager";
			Conn = java.sql.DriverManager.getConnection(url, user, psw);
			String sql="call Insert_Record('数据构','电子工业大学出版社',@SN_bookseller);select @SN_bookseller;";
			java.sql.PreparedStatement stmt = Conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			if(rs.next())out.println(rs.getString(1));
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		out.println("杨硕");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the Post method");
		response.setContentType("text/html;charset=UTF-8");
		//数据库信息
		//java.sql.Connection Conn = null;
		try {
			/*Class.forName("com.mysql.jdbc.Driver").newInstance();
			String user = "root";
			String psw = "lyh2o16";
			String url = "jdbc:mysql://123.206.82.143/library-manager";
			Conn = java.sql.DriverManager.getConnection(url, user, psw);*/
			String driverName="com.mysql.jdbc.Driver"; 
			//数据库信息
			String userName="root"; 
			//密码 
			String userPasswd="lyh2o16"; 
			//数据库名 
			String dbName="library-manager"; 
			//表名 
			String tableName="Demand"; 
			String url="jdbc:mysql://123.206.82.143/"+dbName+"?user="+userName+"&password="+userPasswd+"&characterEncoding=utf-8"; 
			Class.forName("com.mysql.jdbc.Driver").newInstance(); 
			java.sql.Connection conn=DriverManager.getConnection(url);
			/*java.sql.CallableStatement callableStatement = conn.prepareCall("call Insert_Record('数据结构','电子工业大学出版社',@SN_bookseller)");
			ResultSet rs = callableStatement.executeQuery();*/
			String name=request.getParameter("book_name");
			String press=request.getParameter("press");
			String sql="call Insert_Record('"+name+"','"+press+"',@SN_bookseller)";
			out.println(sql);
			java.sql.PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			if(rs.next())out.println(rs.getString(1));
			
		} catch (Exception e) {
			out.println(e);
			
		}
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
